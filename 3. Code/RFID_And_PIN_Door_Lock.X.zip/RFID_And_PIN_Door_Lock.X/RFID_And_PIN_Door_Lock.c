#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = ON       // RE3/MCLR pin function select bit (RE3/MCLR pin function is MCLR)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = ON       // Brown Out Reset Selection bits (BOR enabled)
#pragma config IESO = ON        // Internal External Switchover bit (Internal/External Switchover mode is enabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)


#include <xc.h>
#define _XTAL_FREQ 8000000
// Define keypad column pins
#define C1 RB4
#define C2 RB5
#define C3 RB6
// Define keypad row pins
#define R1 RB0
#define R2 RB1
#define R3 RB2
#define R4 RB3

// Define LCD control pins
#define RS RC0
#define RW RC1
#define EN RC2

//Function Declarations
void keypad(void);
void pin(void);
void Rotation0(void);
void Rotation90(void);
void Rotation180(void);

//Variable Declarations
unsigned int rval[12]={0,0,0,0,0,0,0,0,0,0,0,0};
unsigned int flag=1;
unsigned int index=0;
unsigned int count=0;
unsigned int kval[4]={0,0,0,0};

// Send command to LCD
void lcd_cmd(unsigned char cmd)
{
    PORTD = cmd;                     // Place command on PORTB
    RS = 0;                          // RS = 0 for command
    RW = 0;                          // RW = 0 for write
    EN = 1;                          // EN = 1 to latch data
    __delay_ms(5);                   // Delay for command to process
    EN = 0;                          // EN = 0 to complete command
}

// Send data to LCD
void lcd_DATA(unsigned char DATA)
{
    PORTD = DATA;                    // Place data on PORTB
    RS = 1;                          // RS = 1 for data
    RW = 0;                          // RW = 0 for write
    EN = 1;                          // EN = 1 to latch data
    __delay_ms(2);                   // Delay to simulate data hold
    EN = 0;                          // EN = 0 to complete data write
}

// Send string to LCD
void lcd_STRING(unsigned char name[])
{
    for(int i = 0; name[i] != 0; i++) // Loop through each character in string
    {
        lcd_DATA(name[i]);           // Send each character to LCD
    }
}

// Initialize the LCD
void lcd_init()
{
    lcd_cmd(0x38);                   // Initialize LCD in 2 line, 5x7 matrix
    lcd_cmd(0x06);                   // Set increment mode
    lcd_cmd(0x0C);                   // Display on, cursor off
    lcd_cmd(0x01);                   // Clear display
}

//Function to Activate Keypad
void keypad1(){
    C1=0;C2=1;C3=1;
    if(R4==0)                  // Check if row 4 is active
    {
        lcd_DATA('*');          // Display '' on LCD
        pin();
        count=0;
    }
    while(R4 == 0);          // Wait for key release
}

// Read and process keypad input
void keypad()
{
    // Set all column pins high initially
    C1=0;C2=1;C3=1;
    if(R1==0)                   // Check if row 1 is active
    {
        lcd_DATA('1');// Display '1' on LCD
        kval[count]='1';
        count++;
        while(R1==0);          // Wait for key release
    }
    if(R2==0)                  // Check if row 2 is active
    {
        lcd_DATA('4');         // Display '4' on LCD
        kval[count]='4';
        count++;
        while(R2==0);         // Wait for key release
    }
    if(R3==0)                 // Check if row 3 is active
    {
        lcd_DATA('7');        // Display '7' on LCD
       kval[count]='7';
        count++;
        while(R3==0);        // Wait for key release
    }
    C1=1;C2=0;C3=1;
    if(R1==0)                  // Check if row 1 is active
    {
        lcd_DATA('2');           // Display '2' on LCD
        kval[count]='2';
        count++;
        while(R1==0);          // Wait for key release
    }
    if(R2==0)                  // Check if row 2 is active
    {
        lcd_DATA('5');           // Display '5' on LCD
        kval[count]='5';
        count++;
        while(R2==0);          // Wait for key release
    }
    if(R3==0)                  // Check if row 3 is active
    {
        lcd_DATA('8');           // Display '8' on LCD
        kval[count]='8';
        count++;
        while(R3==0);          // Wait for key release
    }
    if(R4==0)                  // Check if row 4 is active
    {
        lcd_DATA('0');           // Display '0' on LCD
        kval[count]='0';
        count++;
        while(R4==0);          // Wait for key release
    }
    C1=1;C2=1;C3=0;
    if(R1==0)                  // Check if row 1 is active
    {
        lcd_DATA('3');           // Display '3' on LCD
        kval[count]='3';
        count++;
        while(R1==0);          // Wait for key release
    }
    if(R2==0)                  // Check if row 2 is active
    {
        lcd_DATA('6');           // Display '6' on LCD
        kval[count]='6';
        count++;
        while(R2==0);          // Wait for key release
    }
    if(R3==0)                  // Check if row 3 is active
    {
        lcd_DATA('9');           // Display '9' on LCD
        kval[count]='9';
        count++;
        while(R3==0);          // Wait for key release
    }
    if(count==4){
        flag=1;       
        }
    
}
void pin(){
    lcd_init();                      // Initialize the LCD
    lcd_cmd(0x80);                   // Move cursor to the second position on the first line
    lcd_STRING("ENTER THE PIN:");
    lcd_cmd(0xC0);
    while(1){        
       keypad();
       if(flag==1){
           if(kval[0]=='1'&&kval[1]=='2'&&kval[2]=='3'&&kval[3]=='4'){
                lcd_init();                      // Initialize the LCD
                lcd_cmd(0x85);                   // Move cursor to the second position on the first line
                lcd_STRING("WELCOME");
                lcd_cmd(0xC1);                   // Move cursor to the second position on the first line
                lcd_STRING("ACCESS GRANTED");
                Rotation180();
                __delay_ms(2000);
                Rotation0();
                __delay_ms(2000);
                for(int i=0;i<4;i++){
                   kval[i]=0;
                }
                break;
            }
            else{
                count=0;
                for(int i=0;i<4;i++){
                    kval[i]=0;
                }
                lcd_init();                      // Initialize the LCD
                lcd_cmd(0x85);                   // Move cursor to the second position on the first line
                lcd_STRING("SORRY");
                 lcd_cmd(0xC1);                   // Move cursor to the second position on the first line
                lcd_STRING("ACCESS DENIED");
                PORTA=0XFF;
                __delay_ms(1000);
                PORTA=0X00;
                lcd_cmd(0xC0);
                break;
            }
        }
    }
}
void __interrupt() ISR_tc_int(void)
{
    if(RCIF==1)
    {
        RCIF=0;
        rval[index]=RCREG;
        index=(index+1);
    }
}
void main(void)
{
    OSCCON=0x71;
    TRISC=0X80;
    PORTC=0X00;
    TRISA=0X00;
    PORTA=0X00;
    TXSTA=0X20;
    RCSTA=0X90;
    SPBRG=12;
    GIE=1;
    PEIE=1;
    RCIE=1;
    TRISD = 0x00;
    PORTD = 0x00;  // Set RD0-RD3 as input (rows), RD4-RD7 as output
    ANSELH = 0x00;                   // Disable analog inputs on higher bits
    ANSEL = 0x00;                    // Disable analog inputs on lower bits
    TRISB = 0x0f;
    PORTB = 0xff;
    nRBPU=0;
    WPUB=0xFF;
    lcd_init();                      // Initialize the LCD
        lcd_cmd(0x80);                   // Move cursor to the second position on the first line
        lcd_STRING("...RFID BASED...");
        lcd_cmd(0xC0);
        lcd_STRING("DOOR LOCK SYSTEM");
        Rotation0();
        __delay_ms(2000);
while(1)
{   
    if(flag==1){
        lcd_init();                      // Initialize the LCD
        lcd_cmd(0x80);                   // Move cursor to the second position on the first line
        lcd_STRING("USE ACCESS CARD");
        lcd_cmd(0xC0);
        lcd_STRING("OR PRESS*FOR PIN");
        flag=0;
        count=0;
    }
    keypad1();                    // Read and process keypad input
    if(rval[11]=='1'||rval[11]=='4')
    {
        lcd_init();                      // Initialize the LCD
        lcd_cmd(0x85);// Move cursor to the second position on the first line
        lcd_STRING("WELCOME");
        lcd_cmd(0xC1);// Move cursor to the second line
        lcd_STRING("ACCESS GRANTED");
        Rotation180();
        __delay_ms(2000);
        Rotation0();
        __delay_ms(2000);
        for(int i=0;i<12;i++){
            rval[i]=0; 
        }
        index=0;
        flag=1;
    }
    if(rval[11]=='6'){
        PORTA=0XFF;
        lcd_init();                      // Initialize the LCD
        lcd_cmd(0x85);                   // Move cursor to the second position on the first line
        lcd_STRING("SORRY");
        lcd_cmd(0xC1);                   // Move cursor to the second position on the first line
        lcd_STRING("ACCESS DENIED");
        __delay_ms(1000);
        PORTA=0X00;
        for(int i=0;i<12;i++){
            rval[i]=0; 
        }
        index=0;
        flag=1;
    }
    
}
}
void Rotation0() //0 Degree
{
    unsigned int i;
    for(i=0;i<50;i++)
    {
        RC3=1;
        __delay_us(800); // pulse of 800us
        RC3=0;
        __delay_us(19200);
    }
}

void Rotation90() //90 Degree
{
    unsigned int i;
    for(i=0;i<50;i++)
    {
        RC3=1;
        __delay_us(1500); // pulse of 1500us
        RC3=0;
        __delay_us(18500);
    }
}

void Rotation180() //180 Degree
{
    unsigned int i;
    for(i=0;i<50;i++)
    {
        RC3=1;
        __delay_us(2200); // pulse of 2200us
        RC3=0;
        __delay_us(17800);
    }
}